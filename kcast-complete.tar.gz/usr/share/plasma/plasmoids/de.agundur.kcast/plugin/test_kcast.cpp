#include "kcastinterface.h"
#include <QCoreApplication>
#include <QDebug>

int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);

    KCastBridge bridge;
    QStringList devices = bridge.scanDevicesWithCatt();

    qDebug() << "Gefundene Geräte:";
    for (const QString &device : devices) {
        qDebug() << "📡" << device;
    }

    return 0;
}
