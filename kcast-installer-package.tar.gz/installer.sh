#!/usr/bin/env bash

set -e


TMPDIR=$(mktemp -d)
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" &> /dev/null && pwd)"
ARCHIVE="$SCRIPT_DIR/kcast-runtime.tar.gz"
TARGET_PLASMOID_DIR="$HOME/.local/share/plasma/plasmoids/de.agundur.kcast"
TARGET_PLUGIN_DIR="$HOME/.local/lib64/qt6/qml/de/agundur/kcast"

if [[ ":$QML_IMPORT_PATH:" != *":$HOME/.local/lib64/qt6/qml:"* ]]; then
    echo "⚠️  QML_IMPORT_PATH enthält nicht den lokalen Plugin-Pfad."
    read -rp "➕ In ~/.bashrc eintragen? [j/N] " add_path
    if [[ "$add_path" =~ ^[JjYy]$ ]]; then
        echo 'export QML_IMPORT_PATH="$QML_IMPORT_PATH:$HOME/.local/lib64/qt6/qml"' >> ~/.bashrc
        echo "✅ Eintrag hinzugefügt. Neue Terminalsitzung wird ihn automatisch verwenden."
        read -rp "🔄 Aktuelle Shell neu laden (source ~/.bashrc)? [j/N] " reload_now
        if [[ "$reload_now" =~ ^[JjYy]$ ]]; then
            source ~/.bashrc
        fi
    fi
else
    echo "✅ QML_IMPORT_PATH ist bereits korrekt gesetzt."
fi


echo "📦 Extracting $ARCHIVE to temporary directory $TMPDIR..."
tar -xzf "$ARCHIVE" -C "$TMPDIR"

echo "🧹 Removing any previous installation..."
rm -rf "$TARGET_PLASMOID_DIR" "$TARGET_PLUGIN_DIR"

echo "📁 Installing Plasmoid..."
mkdir -p "$TARGET_PLASMOID_DIR"
cp -r "$TMPDIR/package/contents" "$TARGET_PLASMOID_DIR/"
cp "$TMPDIR/package/metadata.json" "$TARGET_PLASMOID_DIR/"

echo "🔌 Installing QML plugin... " $TARGET_PLUGIN_DIR
mkdir -p "$TARGET_PLUGIN_DIR"
cp "$TMPDIR"/build/bin/de/agundur/kcast/* "$TARGET_PLUGIN_DIR/"

mkdir -p "$HOME/.local/share/locale/de/LC_MESSAGES/"
cp "$TMPDIR"/build/locale/de/LC_MESSAGES/kcast.mo $HOME/.local/share/locale/de/LC_MESSAGES/plasma_applet_de.agundur.kcast.mo


echo "🧽 cleaning up"
rm -rf "$TMPDIR"

echo "🔄 Refreshing KDE Plasma system cache..."
kbuildsycoca6 > /dev/null 2>&1 || echo "⚠️  kbuildsycoca6 failed or not found"

echo "✅ Installation finished"

echo
read -rp "🔄 restart Plasma ? (kquitapp6 plasmashell && kstart6 plasmashell)? [j/N] " answer
if [[ "$answer" =~ ^[JjYy]$ ]]; then
    kquitapp6 plasmashell && kstart6 plasmashell
fi
